
package com.mycompany.libraryreservation;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

public class ViewReservationsGUI extends JFrame {

    private String username;
    private DataStorage storage;
    private JPanel panel;

    // Theme
    private static final Color BG = Color.WHITE;
    private static final Color PRIMARY = new Color(0, 70, 140);
    private static final Font LABEL = new Font("SansSerif", Font.PLAIN, 14);
    private static final Font BUTTON = new Font("SansSerif", Font.BOLD, 13);

    public ViewReservationsGUI(String username) {
        this.username = username;

        setTitle("My Reservations");
        setSize(500, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        getContentPane().setBackground(BG);
        setLayout(new BorderLayout(10, 10));

        storage = new DataStorage();

        panel = new JPanel();
        panel.setBackground(BG);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        loadReservations();

        JScrollPane scroll = new JScrollPane(panel);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        JButton back = new JButton("Back");
        styleButton(back);
        back.addActionListener(e -> {
            new UserDashboardGUI(username).setVisible(true);
            dispose();
        });
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setBackground(BG);
        bottom.add(back);
        add(bottom, BorderLayout.SOUTH);
    }

    private void loadReservations() {
        panel.removeAll();

        List<Reservations> reservations = storage.getReservationsForUser(username);

        if (reservations == null || reservations.isEmpty()) {
            JLabel lbl = new JLabel("You have no reservations.");
            lbl.setFont(LABEL);
            panel.add(lbl);
            panel.revalidate();
            panel.repaint();
            return;
        }

        for (Reservations r : reservations) {
            JPanel card = new JPanel(new BorderLayout(5, 5));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));

            JLabel info = new JLabel(
                    "Library: " + r.getLibrary() +
                            " | Topic: " + r.getTopic() +
                            " | Book: " + r.getBook() +
                            " | Date: " + r.getDate()
            );
            info.setFont(LABEL);
            card.add(info, BorderLayout.CENTER);

            JButton cancel = new JButton("Cancel");
            styleButton(cancel);
            cancel.setFont(BUTTON);
            card.add(cancel, BorderLayout.EAST);

            // Action cancel
            cancel.addActionListener(e -> handleCancel(r));

            panel.add(card);
            panel.add(Box.createRigidArea(new Dimension(0, 5)));
        }

        panel.revalidate();
        panel.repaint();
    }

    private void handleCancel(Reservations r) {
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to cancel this reservation?",
                "Confirm Cancellation",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) return;

        String lib = r.getLibrary();
        String topic = r.getTopic();
        String book = r.getBook();
        String date = r.getDate();

        String serverResponse = null;
        boolean usedServer = false;

        try (Socket socket = new Socket("localhost", 9090);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(
                     new InputStreamReader(socket.getInputStream()))) {

            String sendMsg = "CANCEL|" + username + "|" + lib + "|" + topic + "|" + book + "|" + date;
            out.println(sendMsg);
            serverResponse = in.readLine();
            System.out.println("Server says: " + serverResponse);
            usedServer = true;

        } catch (Exception ex) {
            System.out.println("Could not contact server for cancel (fallback to local). Exception: "
                    + ex.getMessage());
        }

        String resultRaw;
        if (usedServer && serverResponse != null) {
            resultRaw = serverResponse;
        } else {
            resultRaw = storage.cancelReservation(username, lib, topic, book, date);
            System.out.println("Local cancel result: " + resultRaw);
        }

        String message;
        if (resultRaw == null) {
            message = "Unknown response.";
        } else if (resultRaw.startsWith("CANCEL|SUCCESS")) {
            message = "Reservation cancelled successfully.";
        } else if (resultRaw.startsWith("CANCEL|NOTFOUND")) {
            message = "Reservation not found.";
        } else if (resultRaw.startsWith("CANCEL|ERROR")) {
            message = "An error occurred while cancelling.";
        } else {
            message = resultRaw;
        }

        JOptionPane.showMessageDialog(this, message);
        loadReservations();
    }

    private void styleButton(JButton btn) {
        btn.setFont(BUTTON);
        btn.setBackground(PRIMARY);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createLineBorder(PRIMARY));
    }

    // اختياري للتجربة
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ViewReservationsGUI gui = new ViewReservationsGUI("testuser");
            gui.setVisible(true);
        });
    }
}